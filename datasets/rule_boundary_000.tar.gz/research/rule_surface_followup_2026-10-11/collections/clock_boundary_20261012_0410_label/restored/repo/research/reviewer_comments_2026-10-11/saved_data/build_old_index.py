#!/usr/bin/env python3
"""Verify the complete preserved holdout and write a portable reuse index.

Reads data only. It does not import a simulator or alter an original record.
All paths in the index are relative to the supplied ABM root.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(root, rel):
    path = root / rel
    require(path.is_file() and not path.is_symlink(), 'Regular input required: ' + rel)
    return json.loads(path.read_text())


def normalize(raw):
    c = dict(raw)
    c.setdefault('block_days', 1.0)
    c.setdefault('model_overrides', {})
    c['warmup_ticks'] = round(c['warmup_days'] * 2592)
    c['observation_ticks'] = round(c['observation_days'] * 2592)
    c['block_ticks'] = 2592
    c['scenarios'] = []
    for original in raw['scenarios']:
        s = dict(original)
        for key, value in [('h0', .9), ('h1', s.get('h0', .9)), ('rho', 0.), ('e', 1.), ('opportunities', 'zone_separate'), ('environment_multiplier', 1.)]:
            s.setdefault(key, value)
        c['scenarios'].append(s)
    return c


def fixed_model(root):
    tree = ast.parse((root / 'research/full_icu_calibration_2026-10-07/run.py').read_text())
    node = next(n.value for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'FIXED_MODEL' for t in n.targets))
    require(isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'dict' and not node.args, 'Unexpected fixed-model declaration')
    result = {}
    for k in node.keywords:
        result[k.arg] = 2592 if isinstance(k.value, ast.Name) and k.value.id == 'TICKS_PER_DAY' else ast.literal_eval(k.value)
    return result


def expected_kwargs(fixed, config, scenario, seed):
    x = dict(fixed, **config['model_overrides'])
    if 'initial_environment_contaminated' in scenario:
        x['initial_environment_contaminated'] = scenario['initial_environment_contaminated']
    x.update(seed=seed, prob_transmission=scenario['p'], icu_hcw_wash_rate=scenario['h0'], outside_hcw_wash_rate=scenario['h0'], hygiene_opportunities=scenario['opportunities'], hygiene_autocorrelation=scenario['rho'], hygiene_efficacy=scenario['e'], environment_multiplier=scenario['environment_multiplier'])
    return x


def build(root):
    prefix = 'research/full_icu_confirmation_2026-10-08/'
    config_rel, seed_rel, report_rel, freeze_rel = [prefix + n for n in ['configs/holdout_all.json', 'seedbook.json', 'holdout_report/report.json', 'freeze_holdout.json']]
    config, seedbook, report, freeze = [load(root, x) for x in [config_rel, seed_rel, report_rel, freeze_rel]]
    require(report['status'] == 'complete' and report['n_paired_jobs'] == 1536, 'Complete holdout report required')
    require(sha(root / config_rel) == 'a99ea9789122a91622fe84ea04fd50558f669a68201c2f5245b656f19933680f', 'Unexpected holdout configuration')
    require(sha(root / seed_rel) == report['seedbook_sha256'], 'Seedbook/report binding')
    require(sha(root / freeze_rel) == report['freeze_sha256'], 'Freeze/report binding')
    fv = dict(freeze); identity = fv.pop('identity_sha256')
    require(hashlib.sha256(canonical(fv).encode()).hexdigest() == identity == report['freeze_identity'], 'Frozen source identity')
    for rel, expected in freeze['files'].items():
        require(sha(root / rel) == expected, 'Frozen source changed: ' + rel)
    seeds = seedbook['seed_blocks']['holdout']
    require(set(seeds) == {'A', 'B'} and len(seeds['A']) == len(seeds['B']) == 256 and len(set(seeds['A'] + seeds['B'])) == 512, 'Original statistical bank structure')
    require(config['seeds'] == seeds['A'] + seeds['B'], 'Original ordered seedbook/config binding')
    fixed = fixed_model(root)
    indexed, metadata, manifests, sources = {}, {}, {}, {}
    actual_members = set()
    for site in ['local', 'cluster']:
        rel = 'results/full_icu_confirmation_2026-10-08/holdout_' + site + '/manifest.json'
        manifest = load(root, rel)
        m = dict(manifest); mid = m.pop('identity')
        require(hashlib.sha256(canonical(m).encode()).hexdigest() == mid, 'Bank canonical identity')
        bank = next(b for b in report['banks'] if b['identity'] == mid)
        require(sha(root / rel) == bank['manifest_sha256'], 'Report manifest byte binding')
        manifests[rel] = bank['manifest_sha256']
        resolved = normalize(manifest['config'])
        require(resolved == manifest['resolved_config'], 'Resolved configuration binding')
        require([s for s in resolved['scenarios']] == normalize(config)['scenarios'], 'Site scenario binding')
        require(resolved['model_overrides'] == config['model_overrides'] and resolved['warmup_days'] == 90 and resolved['observation_days'] == 56, 'Site timing/model binding')
        jobs = [{'job_id': i, 'scenario': s, 'seed': seed} for i, (s, seed) in enumerate((s, seed) for s in resolved['scenarios'] for seed in resolved['seeds'])]
        require(jobs == manifest['jobs'] and len(jobs) == bank['jobs'], 'Planned bank job inventory')
        require(manifest['sources'] == bank['sources'] and manifest['software'] == bank['software'], 'Report source/runtime binding')
        for source, expected in manifest['sources'].items():
            actual = 'research/full_icu_response_2026-10-08/array_worker.py' if source == 'array_worker.py' else source
            require(sha(root / actual) == expected, 'Simulation source binding: ' + actual)
            sources[actual] = expected
        directory = Path(rel).parent / 'completed'
        require({p.name for p in (root / directory).iterdir()} == set(bank['completed_records_sha256']), 'Strict completed directory inventory')
        for job in jobs:
            name = f"job_{job['job_id']:08d}.json"
            record_rel = str(directory / name)
            require(sha(root / record_rel) == bank['completed_records_sha256'][name], 'Completed byte binding: ' + record_rel)
            record = load(root, record_rel)
            require(record['status'] == 'complete' and record['identity'] == mid, 'Record production identity')
            require(all(record[key] == job[key] for key in ['job_id', 'scenario', 'seed']), 'Record planned membership')
            require(all(record['execution'][key] == value for key, value in manifest['software'].items()), 'Record own production runtime')
            require(record['model_kwargs'] == expected_kwargs(fixed, resolved, job['scenario'], job['seed']), 'Record model/config binding')
            key = (job['scenario']['id'], job['seed'])
            require(key not in actual_members, 'Duplicate paired world')
            actual_members.add(key)
            indexed[record_rel] = bank['completed_records_sha256'][name]
            metadata[record_rel] = {'scenario': job['scenario']['id'], 'seed': job['seed'], 'statistical_bank': 'A' if job['seed'] in seeds['A'] else 'B', 'execution_site': site, 'manifest_identity': mid}
    planned = {(s['id'], seed) for s in config['scenarios'] for seed in config['seeds']}
    require(actual_members == planned and len(indexed) == 1536, 'Exact full 3 x 512 membership')
    result = {'schema_version': 1, 'kind': 'verified_original_holdout_reuse_index', 'status': 'pass', 'paths_relative_to': 'ABM_ROOT', 'manifests': manifests, 'records': indexed, 'config': {'path': config_rel, 'sha256': sha(root / config_rel)}, 'seedbook': {'path': seed_rel, 'sha256': sha(root / seed_rel)}, 'report': {'path': report_rel, 'sha256': sha(root / report_rel)}, 'freeze': {'path': freeze_rel, 'sha256': sha(root / freeze_rel), 'identity_sha256': identity}, 'sources': sources, 'record_metadata': metadata, 'ordered_statistical_banks': seeds, 'independent_upper_comparison_seeds': seeds['A'][:128] + seeds['B'][:128], 'n_records': len(indexed), 'n_seeds_per_profile': 512, 'builder_sha256': sha(Path(__file__))}
    result['identity_sha256'] = hashlib.sha256(canonical(result).encode()).hexdigest()
    return result


def main():
    p = argparse.ArgumentParser(); p.add_argument('--abm-root', type=Path, required=True); p.add_argument('--output', type=Path, required=True)
    a = p.parse_args(); result = build(a.abm_root.resolve())
    require(not a.output.exists(), 'Fresh output required')
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'status': 'pass', 'n_records': result['n_records'], 'sha256': sha(a.output), 'identity_sha256': result['identity_sha256']}))


if __name__ == '__main__':
    main()
